namespace Elementary
{
    /// <summary>
    ///     <para>A root element in the system. It is created automatically.</para>
    /// </summary>
    public interface IRootElement : IElement
    {
    }
}